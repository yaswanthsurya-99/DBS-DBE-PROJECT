# SafeHer — Women Safety App

## Run
Open `index.html` in a browser, or use VS Code Live Server.

## Structure
- `index.html` — login page
- `style.css` — styling and responsive layout
- `script.js` — interactions
- `assets/intro.mp4` — cinematic intro video
- `assets/intro-poster.png` — video fallback/poster

The current login UI is front-end only. Firebase Authentication will be connected in the next stage.
