const API =
    "http://localhost:5000";


const sessionCode =
    new URLSearchParams(
        location.search
    ).get("session");


let map = null;

let marker = null;

let accuracyCircle = null;


const $ =
    id => document.getElementById(id);


// ==========================================
// MAP
// ==========================================

function initMap() {

    map =
        L.map("map")
        .setView(
            [17.385, 78.4867],
            13
        );


    L.tileLayer(
        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        {
            attribution:
                "© OpenStreetMap contributors"
        }
    )
    .addTo(map);

}


// ==========================================
// LOAD SESSION
// ==========================================

async function updateSession() {

    if (!sessionCode) {

        $("summary").textContent =
            "No emergency session code supplied.";

        return;

    }


    try {

        const response =
            await fetch(
                `${API}/api/sos/session/${encodeURIComponent(
                    sessionCode
                )}`
            );


        const data =
            await response.json();


        if (
            !response.ok ||
            !data.success
        ) {

            throw new Error(
                data.message ||
                "Session unavailable."
            );

        }


        const session =
            data.session;


        // ----------------------------------
        // TEXT
        // ----------------------------------

        $("person").textContent =
            session.name;


        $("sessionId").textContent =
            session.id;


        $("lastUpdate").textContent =
            new Date(
                session.lastUpdate
            ).toLocaleTimeString();


        $("coords").textContent =
            `${session.latitude.toFixed(5)}, ${session.longitude.toFixed(5)}`;


        $("mapsLink").href =
            session.location;


        $("state").textContent =
            session.active
                ? "● SOS ACTIVE"
                : "Session ended";


        $("summary").textContent =
            session.active
                ? "Emergency location is updating live."
                : "This emergency session has ended.";


        // ----------------------------------
        // MAP
        // ----------------------------------

        const position = [
            session.latitude,
            session.longitude
        ];


        if (!marker) {

            marker =
                L.marker(
                    position
                )
                .addTo(map)
                .bindPopup(
                    `${session.name} — SafeHer`
                );


            accuracyCircle =
                L.circle(
                    position,
                    {
                        radius:
                            session.accuracy ||
                            30
                    }
                )
                .addTo(map);


            map.setView(
                position,
                16
            );

        }

        else {

            marker.setLatLng(
                position
            );


            accuracyCircle
                .setLatLng(
                    position
                )
                .setRadius(
                    session.accuracy ||
                    30
                );

        }

    } catch (error) {

        console.error(
            error
        );


        $("state").textContent =
            "Waiting…";


        $("summary").textContent =
            error.message;

    }

}


// ==========================================
// START
// ==========================================

initMap();

updateSession();

setInterval(
    updateSession,
    3000
);