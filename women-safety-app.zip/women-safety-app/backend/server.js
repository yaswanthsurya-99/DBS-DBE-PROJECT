require("dotenv").config();

const express = require("express");
const cors = require("cors");
const crypto = require("crypto");

const app = express();

app.use(cors());
app.use(express.json({ limit: "2mb" }));

const PORT = 5000;

const GONUMS_URL =
    "https://sms-api.mapthrust.io/dev/bulkV2";

const SENDER_ID = "CHORHA";

const ENTITY_ID =
    "1601461177122457427";

// IMPORTANT:
// This is the template ID from the Gonums URL
// that successfully delivered your test OTP.
const OTP_TEMPLATE_ID =
    "1607100000000380703";

// Optional future SOS DLT template.
// Leave empty until you have an approved SOS template.
const SOS_TEMPLATE_ID =
    process.env.GONUMS_SOS_TEMPLATE_ID || "";


// ==========================================
// TEMPORARY STORAGE
// ==========================================

const otpStore = new Map();
const sosSessions = new Map();


// ==========================================
// HELPERS
// ==========================================

function cleanPhone(value) {
    return String(value || "").replace(/\D/g, "");
}

function validPhone(phone) {
    return /^[6-9]\d{9}$/.test(phone);
}

function mapsLink(latitude, longitude) {
    return `https://maps.google.com/?q=${encodeURIComponent(
        `${latitude},${longitude}`
    )}`;
}

function makeSessionId() {
    return crypto
        .randomBytes(4)
        .toString("hex")
        .toUpperCase();
}


// ==========================================
// GONUMS SMS
// ==========================================

async function sendGonumsSMS({
    phone,
    message,
    templateId
}) {

    const params = new URLSearchParams();

    params.append(
        "authorization",
        process.env.GONUMS_API_KEY || ""
    );

    params.append(
        "route",
        "dlt_manual"
    );

    params.append(
        "message",
        message
    );

    params.append(
        "sender_id",
        SENDER_ID
    );

    params.append(
        "entity_id",
        ENTITY_ID
    );

    params.append(
        "template_id",
        templateId
    );

    params.append(
        "numbers",
        phone
    );


    const url =
        `${GONUMS_URL}?${params.toString()}`;


    const response =
        await fetch(
            url,
            {
                method: "GET",
                headers: {
                    Accept: "application/json"
                }
            }
        );


    const data =
        await response.json();


    return {
        response,
        data
    };
}


// ==========================================
// SERVER TEST
// ==========================================

app.get("/", (req, res) => {

    res.json({
        success: true,
        message: "SafeHer backend is running 🚨"
    });

});


// ==========================================
// SEND OTP
// ==========================================

app.post(
    "/api/send-otp",
    async (req, res) => {

        try {

            const phone =
                cleanPhone(req.body.phone);


            if (!validPhone(phone)) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Enter a valid 10-digit Indian mobile number."

                });

            }


            // -------------------------------
            // GENERATE OTP
            // -------------------------------

            const otp =
                crypto.randomInt(
                    100000,
                    1000000
                ).toString();


            // Save OTP for 5 minutes

            otpStore.set(
                phone,
                {
                    otp,
                    expiresAt:
                        Date.now() +
                        5 * 60 * 1000,
                    attempts: 0
                }
            );


            console.log("");
            console.log(
                "======================================"
            );
            console.log(
                "📱 SAFEHER OTP REQUEST"
            );
            console.log(
                "======================================"
            );
            console.log(
                "Phone:",
                phone
            );
            console.log(
                "OTP:",
                otp
            );


            // -------------------------------
            // EXACT MESSAGE FORMAT
            // FROM YOUR WORKING GONUMS URL
            // -------------------------------

            const message =
                `Hello, ${otp} is the OTP for SafeHer login using your phone number. Do not share it to anyone.`;


            console.log(
                "Message:",
                message
            );


            // -------------------------------
            // SEND TO GONUMS
            // -------------------------------

            const {
                response,
                data
            } =
                await sendGonumsSMS({

                    phone,

                    message,

                    templateId:
                        OTP_TEMPLATE_ID

                });


            console.log(
                "Gonums response:",
                data
            );


            if (
                !response.ok ||
                data.return !== true
            ) {

                otpStore.delete(phone);


                return res.status(502).json({

                    success: false,

                    message:
                        "Gonums could not send the OTP.",

                    details: data

                });

            }


            console.log(
                "✅ Gonums accepted OTP request"
            );

            console.log(
                "Request ID:",
                data.request_id
            );

            console.log(
                "======================================"
            );


            return res.json({

                success: true,

                message:
                    "OTP sent successfully.",

                request_id:
                    data.request_id || null

            });


        } catch (error) {

            console.error(
                "❌ OTP ERROR:",
                error
            );


            return res.status(500).json({

                success: false,

                message:
                    "Could not send OTP."

            });

        }

    }
);


// ==========================================
// VERIFY OTP
// ==========================================

app.post(
    "/api/verify-otp",
    (req, res) => {

        try {

            const phone =
                cleanPhone(req.body.phone);

            const otp =
                String(
                    req.body.otp || ""
                ).trim();


            if (
                !validPhone(phone)
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Invalid phone number."

                });

            }


            if (
                !/^\d{6}$/.test(otp)
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Enter the 6-digit OTP."

                });

            }


            const saved =
                otpStore.get(phone);


            if (!saved) {

                return res.status(400).json({

                    success: false,

                    message:
                        "OTP not found. Please request a new OTP."

                });

            }


            if (
                Date.now() >
                saved.expiresAt
            ) {

                otpStore.delete(phone);

                return res.status(400).json({

                    success: false,

                    message:
                        "OTP expired. Please request a new OTP."

                });

            }


            if (
                saved.attempts >= 5
            ) {

                otpStore.delete(phone);

                return res.status(400).json({

                    success: false,

                    message:
                        "Too many incorrect attempts."

                });

            }


            if (
                saved.otp !== otp
            ) {

                saved.attempts++;

                return res.status(400).json({

                    success: false,

                    message:
                        "Incorrect OTP."

                });

            }


            otpStore.delete(phone);


            console.log(
                `✅ PHONE VERIFIED: ${phone}`
            );


            return res.json({

                success: true,

                message:
                    "Phone number verified successfully."

            });

        } catch (error) {

            console.error(
                "OTP verification error:",
                error
            );

            return res.status(500).json({

                success: false,

                message:
                    "Could not verify OTP."

            });

        }

    }
);


// ==========================================
// START SOS SESSION
// ==========================================

app.post(
    "/api/sos/start",
    async (req, res) => {

        try {

            const {
                name,
                phone,
                latitude,
                longitude,
                guardians = []
            } = req.body;


            if (
                latitude === undefined ||
                longitude === undefined
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Current GPS location is required."

                });

            }


            const sessionId =
                makeSessionId();


            const session = {

                id: sessionId,

                name:
                    name ||
                    "SafeHer user",

                phone:
                    cleanPhone(phone),

                latitude:
                    Number(latitude),

                longitude:
                    Number(longitude),

                accuracy: null,

                speed: null,

                startedAt:
                    Date.now(),

                lastUpdate:
                    Date.now(),

                active: true,

                guardians:
                    Array.isArray(guardians)
                        ? guardians.map(g => ({
                            ...g,
                            phone:
                                cleanPhone(g.phone)
                        }))
                        : []

            };


            sosSessions.set(
                sessionId,
                session
            );


            const location =
                mapsLink(
                    session.latitude,
                    session.longitude
                );


            const smsResults = [];


            // --------------------------------
            // OPTIONAL SOS SMS
            // --------------------------------

            if (
                SOS_TEMPLATE_ID &&
                process.env.GONUMS_API_KEY
            ) {

                for (
                    const guardian
                    of session.guardians
                ) {

                    if (
                        !validPhone(
                            guardian.phone
                        )
                    ) {
                        continue;
                    }


                    const message =
                        `SAFEHER SOS ALERT. ${session.name} needs immediate help. Live location: ${location}`;


                    try {

                        const {
                            response,
                            data
                        } =
                            await sendGonumsSMS({

                                phone:
                                    guardian.phone,

                                message,

                                templateId:
                                    SOS_TEMPLATE_ID

                            });


                        smsResults.push({

                            phone:
                                guardian.phone,

                            accepted:
                                response.ok &&
                                data.return === true,

                            request_id:
                                data.request_id ||
                                null

                        });

                    } catch (error) {

                        smsResults.push({

                            phone:
                                guardian.phone,

                            accepted: false,

                            error:
                                error.message

                        });

                    }

                }

            }


            console.log(
                `🚨 SOS STARTED: ${sessionId}`
            );


            return res.json({

                success: true,

                sessionId,

                location,

                guardianUrl:
                    `/pages/guardian.html?session=${sessionId}`,

                smsConfigured:
                    Boolean(SOS_TEMPLATE_ID),

                smsResults

            });


        } catch (error) {

            console.error(
                "SOS start error:",
                error
            );


            return res.status(500).json({

                success: false,

                message:
                    "Could not start SOS."

            });

        }

    }
);


// ==========================================
// UPDATE SOS LOCATION
// ==========================================

app.post(
    "/api/sos/update",
    (req, res) => {

        const {
            sessionId,
            latitude,
            longitude,
            accuracy,
            speed
        } = req.body;


        const id =
            String(
                sessionId || ""
            ).toUpperCase();


        const session =
            sosSessions.get(id);


        if (
            !session ||
            !session.active
        ) {

            return res.status(404).json({

                success: false,

                message:
                    "SOS session not found."

            });

        }


        session.latitude =
            Number(latitude);

        session.longitude =
            Number(longitude);

        session.accuracy =
            accuracy == null
                ? null
                : Number(accuracy);

        session.speed =
            speed == null
                ? null
                : Number(speed);

        session.lastUpdate =
            Date.now();


        return res.json({

            success: true,

            location:
                mapsLink(
                    session.latitude,
                    session.longitude
                ),

            updatedAt:
                session.lastUpdate

        });

    }
);


// ==========================================
// GET SOS SESSION
// ==========================================

app.get(
    "/api/sos/session/:id",
    (req, res) => {

        const id =
            String(
                req.params.id || ""
            ).toUpperCase();


        const session =
            sosSessions.get(id);


        if (!session) {

            return res.status(404).json({

                success: false,

                message:
                    "Safety session not found."

            });

        }


        return res.json({

            success: true,

            session: {

                ...session,

                location:
                    mapsLink(
                        session.latitude,
                        session.longitude
                    )

            }

        });

    }
);


// ==========================================
// END SOS
// ==========================================

app.post(
    "/api/sos/end",
    (req, res) => {

        const id =
            String(
                req.body.sessionId || ""
            ).toUpperCase();


        const session =
            sosSessions.get(id);


        if (!session) {

            return res.status(404).json({

                success: false,

                message:
                    "Session not found."

            });

        }


        session.active = false;

        session.endedAt =
            Date.now();


        return res.json({

            success: true,

            message:
                "SOS session ended."

        });

    }
);


// ==========================================
// SAFE ROUTE
// ==========================================

app.get(
    "/api/route",
    async (req, res) => {

        try {

            const {
                fromLat,
                fromLng,
                toLat,
                toLng
            } = req.query;


            if (
                [
                    fromLat,
                    fromLng,
                    toLat,
                    toLng
                ].some(
                    value =>
                        value === undefined
                )
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Route coordinates are required."

                });

            }


            const url =
                `https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson&steps=true`;


            const response =
                await fetch(url);


            const data =
                await response.json();


            if (
                !response.ok ||
                data.code !== "Ok"
            ) {

                return res.status(502).json({

                    success: false,

                    message:
                        "Route service unavailable."

                });

            }


            const route =
                data.routes[0];


            return res.json({

                success: true,

                distanceKm:
                    (
                        route.distance /
                        1000
                    ).toFixed(2),

                durationMin:
                    Math.round(
                        route.duration /
                        60
                    ),

                geometry:
                    route.geometry

            });


        } catch (error) {

            console.error(
                "Route error:",
                error
            );


            return res.status(500).json({

                success: false,

                message:
                    "Could not calculate route."

            });

        }

    }
);


// ==========================================
// START SERVER
// ==========================================

app.listen(
    PORT,
    () => {

        console.log("");
        console.log(
            "======================================"
        );
        console.log(
            "🚨 SAFEHER BACKEND"
        );
        console.log(
            "======================================"
        );
        console.log(
            `Server: http://localhost:${PORT}`
        );
        console.log(
            "Gonums OTP: READY"
        );
        console.log(
            "OTP Verification: READY"
        );
        console.log(
            "SOS Session: READY"
        );
        console.log(
            "Live Location: READY"
        );
        console.log(
            "Safe Route: READY"
        );
        console.log(
            "======================================"
        );
        console.log("");

    }
);